/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y51
 */

#ifndef trik_sound_dsp_1__
#define trik_sound_dsp_1__



#endif /* trik_sound_dsp_1__ */ 
